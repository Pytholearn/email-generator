import random
import string

print("Pytho learn^_^")
def email_gen():

    chars_after_at = int(input("Enter how much chars you want after @gmail.com between 4 and 20 max :"))

    if(chars_after_at < 4 or chars_after_at > 20):
        print("Please enter between 4 and 20 chars max !!")
        print("Try again-_-")
        email_gen()
    else:

        letters_list = [string.digits, string.ascii_lowercase, string.ascii_uppercase]

        letters_list_to_str = "".join(letters_list)

        email_format = "@gmail.com"

        email_generated = "".join(random.choices(letters_list_to_str, k=chars_after_at)) + email_format

        print(email_generated)

# call email generator function
email_gen()
email_gen()
email_gen()
email_gen()
